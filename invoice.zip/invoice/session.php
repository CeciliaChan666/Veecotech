<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
session_start(); // Starting Session
include ('db.php');
// Storing Session
$user_check=$_SESSION['login_user'];
// SQL Query To Fetch Complete Information Of User
$ses_sql = "select username from login where username = '$user_check'";
$result=mysqli_query($conn,$ses_sql);
$row = mysqli_fetch_assoc($result);
$login_session = $row['username'];
if(!isset($login_session))
{
	mysqli_close($conn); //Closing Connection
	header('Location: ../login.php'); //Redirecting to Home Page
}
?>