<?php
session_start(); //starting session
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
include 'db.php';
?>
<?php
$error = "";
$msg = "";
if(isset($_POST['submit']))
{
  if(empty($_POST['username']) || empty($_POST['password']))
	{
		$error = "Please enter your username and password";
	}
  else
	{
		$username = mysqli_real_escape_string($conn,$_POST['username']);
		$password = mysqli_real_escape_string($conn,$_POST['password']);
		$query= "select * from login where BINARY password='$password' AND username='$username'";
		$result = mysqli_query($conn, $query);
		$row = mysqli_num_rows($result);
		
		if($row == 1)
		{
			$row1 = mysqli_fetch_assoc($result);
			$level = $row1['level'];
      if($level == 'admin')
      {
        $_SESSION['login_user']=$username; //initializing session
			  header("location: admin/index.php"); //redirecting to other page
			}
      elseif($level == 'customer')
      {
        $_SESSION['login_user']=$username; //initializing session
        header("location: customer/index.php"); //redirecting to other page
			}
			else
      {
        
        header("location: login.php"); //redirecting to other page
			}
    }
    if($row != 1)
		{
			$error="Username and password is invalid";
		}
  }
}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSS-->
     <link rel="shortcut icon" href="Images/Veecotech_logo.ico" type="image/x-icon"> <link rel="stylesheet" type="text/css" href="css/main.css">
    <title>Mindbrainsolutions</title>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries-->
    <!--if lt IE 9
    script(src='https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js')
    script(src='https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js')
    -->
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/essential-plugins.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/pace.min.js"></script>
    <script src="js/main.js"></script>
  </head>
  <body>
    <section class="material-half-bg">
      <div class="cover"></div>
    </section>
    <section class="login-content" style="background-color:white">
      <div class="logo">
        <img src="../invoice/images/logo.jpg">
      </div>
      <!--sign-in form-->
      <div class="login-box">
        <form action="" class="login-form" method="post">
          <h3 class="login-head"><i class="fa fa-lg fa-fw fa-user"></i>SIGN IN</h3>
          <div class="form-group">
            <label class="control-label">USERNAME</label>
            <input type="text" name="username" placeholder="Name" autofocus class="form-control">
          </div>
          <div class="form-group">
            <label class="control-label">PASSWORD</label>
            <input type="password" name="password" placeholder="Password" class="form-control">
          </div>
          <?php
          if ($error != "")
          {
            echo '<span class="alert alert-danger">' .$error. '</span><br><br>';
          }
          if ($msg != "")
          {
            echo '<span class="alert alert-success">' .$msg. '</span><br><br>';
          }
          ?>
          <div class="form-group">
            <div class="utility">
              <div class="animated-checkbox">
              </div>
            </div>
          </div>
          <div class="form-group btn-container">
            <button class="btn btn-primary btn-block" name="submit">SIGN IN <i class="fa fa-sign-in fa-lg"></i></button>
          </div>
        </form>
      </div>
    </section>
  </body>
</html>
