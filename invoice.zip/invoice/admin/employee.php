<?php
include('../session.php');
include_once '../db.php';

if(isset($_POST['insert']))
{
	$comp_name = $_POST['comp_name'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$date = $_POST['date'];
	$month = date("m",strtotime($date));
	$query1= "INSERT INTO login (comp_name,username,password,level,month_reg,month) VALUES ('$comp_name','$username','$password','customer','$date','$month')";	
	mysqli_query($conn, $query1);
	$query2= "INSERT INTO company (comp_name,month_reg) VALUES ('$comp_name','$date')";	
	mysqli_query($conn, $query2);
}
if(isset($_GET['delete_id']))
{  	
	$sql1="SELECT * FROM login where id=".$_GET['delete_id'];
    $result1= mysqli_query($conn, $sql1);
    $row1 = mysqli_fetch_assoc($result1);
	$comp_name = $row1['comp_name'];
	$query1="DELETE FROM login WHERE id=".$_GET['delete_id'];
    $query2="DELETE FROM company WHERE comp_name = '$comp_name'";
	mysqli_query($conn, $query1);
    mysqli_query($conn, $query2);
	header("Location: employee.php");
}
if(isset($_POST['update']))
{
	$id = $_POST['id'];
	$comp_name = $_POST['update_comp'];
    $username = $_POST['update_user'];
	$date = $_POST['update_date'];
	$query1= "UPDATE login SET comp_name='$comp_name', username='$username', date_reg='$date' WHERE id='$id'";
	$query2= "UPDATE company SET date_reg='$date' WHERE id='$id'";
	mysqli_query($conn, $query1);
	mysqli_query($conn, $query2);
}
?>
<!DOCTYPE html>
<html>
  <head>
  <link rel="shortcut icon" href="Images/Veecotech_logo.ico" type="image/x-icon">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSS-->
    <link rel="stylesheet" type="text/css" href="../css/main.css">
    <title>Welcome Admin</title>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries-->
    <!--if lt IE 9
    script(src='https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js')
    script(src='https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js')
    -->
  </head>
  <body class="sidebar-mini fixed">
    <div class="wrapper">
      <!-- Navbar-->
      <header class="main-header hidden-print"><a href="#" class="logo">Veecotech</a>
        <nav class="navbar navbar-static-top">
          <!-- Sidebar toggle button--><a href="#" data-toggle="offcanvas" class="sidebar-toggle"></a>
          <!-- Navbar Right Menu-->
          <div class="navbar-custom-menu">
            <ul class="top-nav">
              <!-- User Menu-->
              <li class="dropdown"><a href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-user fa-lg"></i></a>
                <ul class="dropdown-menu settings-menu">
                  <li><a href="../logout.php"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Side-Nav-->
      <aside class="main-sidebar hidden-print">
        <section class="sidebar">
          <div class="user-panel">
            <div class="pull-left image"><img src="../images/admin.jpg" alt="User Image" class="img-circle"></div>
            <div class="pull-left info">
              <p>Hi, <?php echo $login_session;?> !</p>
              <p class="designation">Administrator</p>
            </div>
          </div>
          <!-- Sidebar Menu-->
          <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fa fa-dashboard"></i><span>Dashboard</span></a></li>
            <li class="active"><a href="employee.php"><i class="fa fa-users"></i><span>Company</span></a></li>                    
          </ul>
        </section>
      </aside>
      <div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-users"></i> Company Details</h1>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li><a href="employee.php">Company Details</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
			<!-- Trigger the modal with a button -->
			<div class="pull-right">
			<button type="submit" class="btn btn-success" data-toggle="modal" data-target="#myModal">Add New Customer</button><br><br>
			</div>
			<!-- Modal -->
			<div id="myModal" class="modal fade" role="dialog">
			  <div class="modal-dialog">
			
				<!-- Modal content-->
				<div class="modal-content">
				  <div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Add Customer Data</h4>
				  </div>
				  <form action="" name="myForm" method="post">
				  <div class="modal-body">
								<label>Company Name</label>
								<input type="text" name="comp_name" id="comp_name" class="form-control" placeholder="Lee Sdn Bhd">
								<label>User Name</label>
								<input type="text" name="username" id="username" class="form-control" placeholder="lee">
								<label>Password</label>
								<input type="password" name="password" id="password" class="form-control" placeholder="qwerty12345">
								<label>Date Registered</label>
								<input type="date" name="date" id="month" class="form-control">
				  </div>
				  <div class="modal-footer">
					<button type="button" name="insert" class="btn btn-success" onClick="validateForm();">Add</button>
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				  </div>
				  </form>
				</div>
			  </div>
			  </div>
              <div class="card-body">
                <table class="table table-hover table-bordered">
                  <thead>
                    <tr>
                      <th>No.</th>  
                      <th>Company Name</th>
					  <th>User Name</th>
                      <th>Password</th>
					  <th>Month Registered</th>
					  <th colspan="2">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                      <?php
					$ctr = 1;
					$query="SELECT * FROM login WHERE level='customer'";
					$result_set=mysqli_query($conn,$query);
					while($row=mysqli_fetch_row($result_set))
					{
						?>
							<tr>
								<td><?php echo $ctr; ?></td>
								<td><?php echo $row[1]; ?></td>
								<td><?php echo $row[2]; ?></td>
								<td><input type="password" value="<?php echo $row[3]; ?>" readonly></td>
								<td><?php echo $row[5]; ?></td>
								<td align="center"><button class="btn btn-info" data-toggle="modal" data-target="#edit-<?php echo $row[0]; ?>">Edit</button></td>
								
								<div id="edit-<?php echo $row[0]; ?>" tabindex="-1" class="modal fade" role="dialog">
								<div class="modal-dialog">
								<div class="modal-content">
								  <div class="modal-header">
									<button type="button" class="close" data-dismiss="modal">&times;</button>
									<h4 class="modal-title">Edit Company Data</h4>
								  </div>
								  <form action="" name="myForm" method="POST">
								  <div class="modal-body">
												<input type="hidden" name="id" value="<?php echo $row[0]; ?>" >
												<label>Company Name</label>
												<input type="text" name="update_comp" id="update_comp" class="form-control" value="<?php echo $row[1]; ?>" required>
												<label>User Name</label>
												<input type="text" name="update_user" id="update_user" class="form-control" value="<?php echo $row[2]; ?>" required>
												<label>Date Registered</label>
												<input type="date" name="update_date" id="update_date" class="form-control" value="<?php echo $row[5]; ?>" required>
								  </div>
								  <div class="modal-footer">
									<button type="submit" name="update" class="btn btn-success">Update</button>
									<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								  </div>
								  </form>
								</div>
							  </div>
							</div>
						<td align="center"><a href="javascript:delete_id('<?php echo $row[0]; ?>')" class="btn btn-warning">DELETE</a></td>
					</tr>
					<?php
						$ctr++;
						}
					?>
                    </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Javascripts-->
    <script src="../js/jquery-2.1.4.min.js"></script>
    <script src="../js/essential-plugins.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/plugins/pace.min.js"></script>
    <script src="../js/main.js"></script>
    <script>
      function validateForm()
      {
        if (document.getElementById("comp_name").value === "" )
		{
            alert("Please insert the customer name");
			window.setTimeout(function ()
			{
				document.getElementById('comp_name').focus();
			}, 0);
		return false;
        }
		else if (!/^[a-zA-Z ]*$/g.test(document.getElementById("comp_name").value))
		{
			alert("Company name must be in alphabet only");
			window.setTimeout(function ()
			{
				document.getElementById('comp_name').focus();
			}, 0);
		return false;
		}
		else if (document.getElementById("username").value === "" )
		{
            alert("Please insert the user name");
			window.setTimeout(function ()
			{
				document.getElementById('username').focus();
			}, 0);
		return false;
        }
		else if (!/^[a-zA-Z ]*$/g.test(document.getElementById("username").value))
		{
			alert("Username must be in alphabet only");
			window.setTimeout(function ()
			{
				document.getElementById('username').focus();
			}, 0);
		return false;
		}
		else if (document.getElementById("password").value === "")
		{
            alert("Please insert the password");
			window.setTimeout(function ()
			{
				document.getElementById('password').focus();
			}, 0);
		return false;
        }
		else if (document.getElementById("month").value === "")
		{
			alert("Please insert the month registered");
			window.setTimeout(function ()
			{
				document.getElementById('month').focus();
			}, 0);
		return false;
		}
		else
        {
          document.getElementsByName("insert")[0].type = "submit";
        }
    }      
    </script>
    <script type="text/javascript">
	function delete_id(id)
	{
		if(confirm('Are you sure want to delete the customer data?'))
		{
			window.location.href='employee.php?delete_id='+id;
		}
	}
	</script>
  </body>
</html>