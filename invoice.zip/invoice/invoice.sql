-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 22, 2018 at 12:13 PM
-- Server version: 5.7.11
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `invoice`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id` int(11) NOT NULL,
  `comp_name` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `contact_no` varchar(100) DEFAULT NULL,
  `comp_email` varchar(100) DEFAULT NULL,
  `month_reg` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `comp_name`, `address`, `contact_no`, `comp_email`, `month_reg`, `description`) VALUES
(21, 'Chair Sdn Bhd', '399-2-3,tdsa,jelutong, peanng', NULL, NULL, '2018-08-08', NULL),
(22, 'Fan Sdn Bhd', 'taman dato syed abssss', '010012312', 'grd_5353@yahoo.com', '2018-07-07', NULL),
(20, 'Table Sdn Bhd', 'padang bola sepak', NULL, NULL, '2018-08-01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `id` int(11) NOT NULL,
  `comp_name` varchar(20) DEFAULT NULL,
  `cust_name` varchar(20) DEFAULT NULL,
  `product` varchar(30) DEFAULT NULL,
  `quantity` int(10) DEFAULT NULL,
  `price` int(100) NOT NULL,
  `date` varchar(30) DEFAULT NULL,
  `month` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`id`, `comp_name`, `cust_name`, `product`, `quantity`, `price`, `date`, `month`) VALUES
(2, 'Fan Sdn Bhd', 'Mr Leu', 'tables', 3, 100, '2018-07-06', '12'),
(5, 'Fan Sdn Bhd', 'MR LEE', 'chair', 2, 50, '2018-07-14', '07'),
(7, 'Fan Sdn Bhd', 'kiki', 'o', 2, 30, '2018-07-08', '07');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `comp_name` varchar(30) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(30) NOT NULL,
  `level` varchar(20) NOT NULL,
  `month_reg` varchar(100) DEFAULT NULL,
  `month` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `comp_name`, `username`, `password`, `level`, `month_reg`, `month`) VALUES
(1, 'Paint Sdn. Bhd', 'paint', '123', 'admin', '2018-01-30', '01'),
(22, 'Chair Sdn Bhd', 'chair', '123', 'customer', '2018-08-08', '08'),
(21, 'Table Sdn Bhd', 'table', '123', 'customer', '2018-08-01', '08'),
(23, 'Fan Sdn Bhd', 'fan', '123', 'customer', '2018-07-07', '07');

-- --------------------------------------------------------

--
-- Table structure for table `quotation`
--

CREATE TABLE `quotation` (
  `id` int(11) NOT NULL,
  `comp_name` varchar(100) NOT NULL,
  `cust_name` varchar(100) NOT NULL,
  `product` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quotation`
--

INSERT INTO `quotation` (`id`, `comp_name`, `cust_name`, `product`, `quantity`, `price`, `date`) VALUES
(1, 'Fan Sdn Bhd', 'MR LEE', 'chair', 3, 100, '2018-07-08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quotation`
--
ALTER TABLE `quotation`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `quotation`
--
ALTER TABLE `quotation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
