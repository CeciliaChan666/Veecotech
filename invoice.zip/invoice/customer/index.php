<?php
include('../session.php');
include_once '../db.php';
?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="shortcut icon" href="Images/Veecotech_logo.ico" type="image/x-icon">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSS-->
    <link rel="stylesheet" type="text/css" href="../css/main.css">
    <title>Welcome Customer</title>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries-->
    <!--if lt IE 9
    script(src='https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js')
    script(src='https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js')
    -->
  </head>
  <body class="sidebar-mini fixed">
    <div class="wrapper">
      <!-- Navbar-->
      <header class="main-header hidden-print"><a href="#" class="logo">Veecotech</a>
        <nav class="navbar navbar-static-top">
          <!-- Sidebar toggle button--><a href="#" data-toggle="offcanvas" class="sidebar-toggle"></a>
          <!-- Navbar Right Menu-->
          <div class="navbar-custom-menu">
            <ul class="top-nav">
              <!-- User Menu-->
              <li class="dropdown"><a href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-user fa-lg"></i></a>
                <ul class="dropdown-menu settings-menu">
                  <li><a href="setting.php"><i class="fa fa-cog fa-lg"></i> Settings</a></li>
                  <li><a href="../logout.php"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Side-Nav-->
      <aside class="main-sidebar hidden-print">
        <section class="sidebar">
          <div class="user-panel">
            <div class="pull-left image"><img src="../images/employee.png" alt="User Image" class="img-circle"></div>
            <div class="pull-left info">
              <p>Hi, <?php echo $login_session;?> !</p>
              <p class="designation">Employee</p>
            </div>
          </div>
          <!-- Sidebar Menu-->
          <ul class="sidebar-menu">
            <li class="active"><a href="index.php"><i class="fa fa-dashboard"></i><span>Dashboard</span></a></li>
            <li><a href="invoice.php"><i class="fa fa-envelope-o"></i><span>Invoice</span></a></li>
            <li><a href="quotation.php"><i class="fa fa-external-link"></i><span>Quotation</span></a></li>
          </ul>
        </section>
      </aside>
      <div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-dashboard"></i> Dashboard</h1>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li><a href="index.php">Dashboard</a></li>
            </ul>
          </div>
        </div>
        <div class="row mt-20">
          <div class="col-md-12">
            <div class="card">
              <div id="container1" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
                <table id="datatable1" hidden>
                    <thead>
                        <tr>
                            <th></th>
                            <th>January</th>
                            <th>February</th>
                            <th>March</th>
                            <th>April</th>
                            <th>May</th>
                            <th>June</th>
                            <th>July</th>
                            <th>August</th>
                            <th>September</th>
                            <th>October</th>
                            <th>November</th>
                            <th>December</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $querys = "SELECT comp_name FROM login WHERE username='$login_session'";
                        $results = mysqli_query($conn,$querys);
                        $rows = mysqli_fetch_assoc($results);
                        $comp_name = $rows['comp_name'];
                        //january
                        $query1="SELECT * FROM invoice WHERE comp_name='$comp_name' AND month='01'";
                        $result1=mysqli_query($conn,$query1);
                        $row1=mysqli_num_rows($result1);
                        //february
                        $query2="SELECT * FROM invoice WHERE comp_name='$comp_name' AND month='02'";
                        $result2=mysqli_query($conn,$query2);
                        $row2=mysqli_num_rows($result2);
                        //march
                        $query3="SELECT * FROM invoice WHERE comp_name='$comp_name' AND month='03'";
                        $result3=mysqli_query($conn,$query3);
                        $row3=mysqli_num_rows($result3);
                        //april
                        $query4="SELECT * FROM invoice WHERE comp_name='$comp_name' AND month='04'";
                        $result4=mysqli_query($conn,$query4);
                        $row4=mysqli_num_rows($result4);
                        //may
                        $query5="SELECT * FROM invoice WHERE comp_name='$comp_name' AND month='05'";
                        $result5=mysqli_query($conn,$query5);
                        $row5=mysqli_num_rows($result5);
                        //june
                        $query6="SELECT * FROM invoice WHERE comp_name='$comp_name' AND month='06'";
                        $result6=mysqli_query($conn,$query6);
                        $row6=mysqli_num_rows($result6);
                        //july
                        $query7="SELECT * FROM invoice WHERE comp_name='$comp_name' AND month='07'";
                        $result7=mysqli_query($conn,$query7);
                        $row7=mysqli_num_rows($result7);
                        //august
                        $query8="SELECT * FROM invoice WHERE comp_name='$comp_name' AND month='08'";
                        $result8=mysqli_query($conn,$query8);
                        $row8=mysqli_num_rows($result8);
                        //september
                        $query9="SELECT * FROM invoice WHERE comp_name='$comp_name' AND month='09'";
                        $result9=mysqli_query($conn,$query9);
                        $row9=mysqli_num_rows($result9);
                        //oct
                        $query10="SELECT * FROM invoice WHERE comp_name='$comp_name' AND month='10'";
                        $result10=mysqli_query($conn,$query10);
                        $row10=mysqli_num_rows($result10);
                        //nov
                        $query11="SELECT * FROM invoice WHERE comp_name='$comp_name' AND month='11'";
                        $result11=mysqli_query($conn,$query11);
                        $row11=mysqli_num_rows($result11);
                        //dec
                        $query12="SELECT * FROM invoice WHERE comp_name='$comp_name' AND month='12'";
                        $result12=mysqli_query($conn,$query12);
                        $row12=mysqli_num_rows($result12);
                        ?>
                        <tr>
                            <th>Number of Invoice</th>
                            <td><?php echo $row1; ?></td>
                            <td><?php echo $row2; ?></td>
                            <td><?php echo $row3; ?></td>
                            <td><?php echo $row4; ?></td>
                            <td><?php echo $row5; ?></td>
                            <td><?php echo $row6; ?></td>
                            <td><?php echo $row7; ?></td>
                            <td><?php echo $row8; ?></td>
                            <td><?php echo $row9; ?></td>
                            <td><?php echo $row10; ?></td>
                            <td><?php echo $row11; ?></td>
                            <td><?php echo $row12; ?></td>
                        </tr>
                    </tbody>
                </table>    
            </div>           
          </div>     
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
    <!-- Javascripts-->
    <script src="../js/chart/highcharts.js"></script>
    <script src="../js/chart/data.js"></script>
    <script src="../js/chart/exporting.js"></script>
    <script src="../js/jquery-2.1.4.min.js"></script>
    <script src="../js/essential-plugins.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/plugins/pace.min.js"></script>
    <script src="../js/main.js"></script>
    <script>
        Highcharts.chart('container1', {
            data: {
                table: 'datatable1'
            },
            chart: {
                type: 'column'
            },
            title: {
                text: 'Number of Invoice'
            },
            yAxis: {
                allowDecimals: false,
                title: {
                    text: 'Number'
                }
            },
            tooltip: {
                formatter: function () {
                    return '<b>' + this.series.name + '</b><br/>' +
                         this.point.y + ' ' + this.point.name.toLowerCase();
                }
            },
            credits: {
                enabled: false
            }
        });
    </script>
  </body>
</html>