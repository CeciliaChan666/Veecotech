<?php
include('../session.php');
include_once '../db.php';
?>
<?php
if(isset($_POST['update']))
{
	$id = $_POST['id'];
	$name = $_POST['update_name'];
    $address = $_POST['update_address'];
	$contact = $_POST['update_contact'];
	$email = $_POST['update_email'];
	$query= "UPDATE company SET comp_name='$name', address='$address', contact_no='$contact', comp_email='$email' WHERE id='$id'";
	mysqli_query($conn, $query);
}
?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="shortcut icon" href="Images/Veecotech_logo.ico" type="image/x-icon">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSS-->
    <link rel="stylesheet" type="text/css" href="../css/main.css">
    <title>Institution</title>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries-->
    <!--if lt IE 9
    script(src='https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js')
    script(src='https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js')
    -->
  </head>
  <body class="sidebar-mini fixed">
    <div class="wrapper">
      <!-- Navbar-->
      <header class="main-header hidden-print"><a href="#" class="logo">Veecotech</a>
        <nav class="navbar navbar-static-top">
          <!-- Sidebar toggle button--><a href="#" data-toggle="offcanvas" class="sidebar-toggle"></a>
          <!-- Navbar Right Menu-->
          <div class="navbar-custom-menu">
            <ul class="top-nav">
              <!-- User Menu-->
              <li class="dropdown"><a href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-user fa-lg"></i></a>
                <ul class="dropdown-menu settings-menu">
					<li><a href="setting.php"><i class="fa fa-cog fa-lg"></i> Settings</a></li>
                  <li><a href="../logout.php"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Side-Nav-->
      <aside class="main-sidebar hidden-print">
        <section class="sidebar">
          <div class="user-panel">
            <div class="pull-left image"><img src="../images/employee.png" alt="User Image" class="img-circle"></div>
            <div class="pull-left info">
              <p>Hi, <?php echo $login_session;?> !</p>
              <p class="designation">Customer</p>
            </div>
          </div>
          <!-- Sidebar Menu-->
          <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fa fa-dashboard"></i><span>Dashboard</span></a></li>
            <li><a href="invoice.php"><i class="fa fa-envelope-o"></i><span>Invoice</span></a></li>
            <li class="active"><a href="quotation.php"><i class="fa fa-external-link"></i><span>Quotation</span></a></li>
          </ul>
        </section>
      </aside>
      <div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-users"></i> Settings</h1>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li><a href="setting.php">Settings</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <table class="table table-hover table-bordered">
                  <thead>
                    <tr>
                      <th>Company Name</th>
                      <th>Address</th>
                      <th>Contact No.</th>
					  <th>Email</th>
					  <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                      <?php
					$querys = "SELECT comp_name FROM login WHERE username='$login_session'";
                        $results = mysqli_query($conn,$querys);
                        $rows = mysqli_fetch_assoc($results);
                        $comp_name = $rows['comp_name'];
						
					$query="SELECT * FROM company WHERE comp_name='$comp_name'";
					$result_set=mysqli_query($conn,$query);
					while($row=mysqli_fetch_row($result_set))
					{
						?>
							<tr>
								<td><?php echo $row[1]; ?></td>
								<td><?php echo $row[2]; ?></td>
								<td><?php echo $row[3]; ?></td>
								<td><?php echo $row[4]; ?></td>
								<td align="center"><button class="btn btn-info" data-toggle="modal" data-target="#edit-<?php echo $row[0]; ?>">Edit</button></td>
								
								<div id="edit-<?php echo $row[0]; ?>" tabindex="-1" class="modal fade" role="dialog">
								<div class="modal-dialog">
								<div class="modal-content">
								  <div class="modal-header">
									<button type="button" class="close" data-dismiss="modal">&times;</button>
									<h4 class="modal-title">Edit Student Data</h4>
								  </div>
								  <form action="" name="myForm" method="POST">
								  <div class="modal-body">
												<input type="hidden" name="id" value="<?php echo $row[0]; ?>" >
												<label>Company Name</label>
												<input type="text" name="update_name" id="update_name" class="form-control" value="<?php echo $row[1]; ?>">
												<label>Address</label>
												<input type="text" name="update_address" id="update_address" class="form-control" value="<?php echo $row[2]; ?>">
												<label>Contact No.</label>
												<input type="text" name="update_contact" id="update_contact" class="form-control" value="<?php echo $row[3]; ?>">
												<label>Email</label>
												<input type="email" name="update_email" id="update_email" class="form-control" value="<?php echo $row[4]; ?>">
								  </div>
								  <div class="modal-footer">
									<button type="button" name="update" class="btn btn-success" onclick="validateForm();">Update</button>
									<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								  </div>
								  </form>
								</div>
							  </div>
							</div>
					</tr>
					<?php
						}
					?>
                    </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Javascripts-->
    <script src="../js/jquery-2.1.4.min.js"></script>
    <script src="../js/essential-plugins.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/plugins/pace.min.js"></script>
    <script src="../js/main.js"></script>
    <script>
      function validateForm()
      {
        if (document.getElementById("update_name").value === "" )
		{
            alert("Please insert the company name");
			window.setTimeout(function ()
			{
				document.getElementById('update_name').focus();
			}, 0);
		return false;
        }
		else if (!/^[a-zA-Z ]*$/g.test(document.getElementById("update_name").value))
		{
			alert("Company name must be in alphabet only");
			window.setTimeout(function ()
			{
				document.getElementById('update_name').focus();
			}, 0);
		return false;
		}
		else if (document.getElementById("update_address").value === "")
		{
            alert("Please insert the address");
			window.setTimeout(function ()
			{
				document.getElementById('update_address').focus();
			}, 0);
		return false;
        }
		else if (document.getElementById("update_contact").value === "")
		{
            alert("Please insert the contact number");
			window.setTimeout(function ()
			{
				document.getElementById('update_contact').focus();
			}, 0);
		return false;
        }
		else if (document.getElementById("update_email").value === "")
		{
			alert("Please insert the email");
			window.setTimeout(function ()
			{
				document.getElementById('update_email').focus();
			}, 0);
		return false;
		}
		else if (!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.getElementById("update_email").value))
		{
			alert("You have entered an invalid email address");
			window.setTimeout(function ()
			{
				document.getElementById('update_email').focus();
			}, 0);
		return false;
		}
		else
        {
          document.getElementsByName("update")[0].type = "submit";
        }
    }      
    </script>
  </body>
</html>