<?php
include('../session.php');
include_once '../db.php';

$querys = "SELECT comp_name FROM login WHERE username='$login_session'";
$results = mysqli_query($conn,$querys);
$rows = mysqli_fetch_assoc($results);
$comp_name = $rows['comp_name'];
          
if(isset($_POST['insert']))
{
	$name = $_POST['name'];
	$pro = $_POST['pro'];
	$quant = $_POST['quant'];
  $price = $_POST['price'];
	$date = $_POST['date'];
  $month = date("m",strtotime($date));
	$query1= "INSERT INTO invoice (comp_name,cust_name,product,quantity,price,date,month) VALUES ('$comp_name','$name','$pro','$quant','$price','$date','$month')";
	mysqli_query($conn, $query1);
}
if(isset($_GET['delete_id']))
{
    $sql_query1="DELETE FROM invoice WHERE id=".$_GET['delete_id'];
    mysqli_query($conn, $sql_query1);
    header("Location: invoice.php");
}
if(isset($_POST['add']))
{
	// edit login table data
  $id = $_POST['update_id'];
	$update_name = $_POST['update_name'];
	$update_pro = $_POST['update_pro'];
	$update_quant = $_POST['update_quant'];
  $update_date = $_POST['update_date'];
	$query2= "UPDATE invoice SET cust_name='$update_name', product='$update_pro', quantity='$update_quant', date='$update_date' Where id='$id'";
	mysqli_query($conn, $query2);
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSS-->
    <link rel="stylesheet" type="text/css" href="../css/main.css">
    <title>Invoice</title>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries-->
    <!--if lt IE 9
    script(src='https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js')
    script(src='https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js')
    -->
  </head>
  <body class="sidebar-mini fixed">
    <div class="wrapper">
      <!-- Navbar-->
      <header class="main-header hidden-print"><a href="#" class="logo">Veecotech</a>
        <nav class="navbar navbar-static-top">
          <!-- Sidebar toggle button--><a href="#" data-toggle="offcanvas" class="sidebar-toggle"></a>
          <!-- Navbar Right Menu-->
          <div class="navbar-custom-menu">
            <ul class="top-nav">
              <!-- User Menu-->
              <li class="dropdown"><a href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-user fa-lg"></i></a>
                <ul class="dropdown-menu settings-menu">
                  <li><a href="setting.php"><i class="fa fa-cog fa-lg"></i> Settings</a></li>
                  <li><a href="../logout.php"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Side-Nav-->
      <aside class="main-sidebar hidden-print">
        <section class="sidebar">
          <div class="user-panel">
            <div class="pull-left image"><img src="../images/employee.png" alt="User Image" class="img-circle"></div>
            <div class="pull-left info">
              <p>Hi, <?php echo $login_session;?> !</p>
              <p class="designation">Employee</p>
            </div>
          </div>
          <!-- Sidebar Menu-->
          <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fa fa-dashboard"></i><span>Dashboard</span></a></li>
            <li class="active"><a href="invoice.php"><i class="fa fa-envelope-o"></i><span>Invoice</span></a></li>
            <li><a href="quotation.php"><i class="fa fa-external-link"></i><span>Quotation</span></a></li>
          </ul>
        </section>
      </aside>
      <div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-envelope-o"></i> Invoice</h1>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Invoice</li>
              <li class="active"><a href="invoice.php">Invoice</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
							<!-- Trigger the modal with a button -->
							<div class="pull-right">
<button type="submit" class="btn btn-success" data-toggle="modal" data-target="#myModal">Add New Invoice</button><br><br>
							</div>
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add Invoice</h4>
      </div>
	  <form action="" name="myForm" method="post">
      <div class="modal-body">
					<label>Customer Name</label>
					<input type="text" name="name" id="name" class="form-control" placeholder="Nur Izzati">
					<label>Product</label>
					<input type="text" name="pro" id="pro" class="form-control" placeholder="tables">
					<label>Quantity</label>
					<input type="number" min="1" name="quant" id="quant" class="form-control" placeholder="2">
          <label>Price</label>
					<input type="number" min="1" name="price" id="price" class="form-control" placeholder="2">
					<label>Date</label>
					<input type="date" name="date" id="date" class="form-control">
      </div>
      <div class="modal-footer">
		<button type="button" name="insert" class="btn btn-success" onClick="validateForm();">Add</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
	  </form>
    </div>
  </div>
</div>
              <div class="card-body">
                <table class="table table-hover table-bordered">
                  <thead>
                    <tr>
                      <th>No.</th>  
                      <th>Customer Name</th>
                      <th>Product</th>
                      <th>Quantity</th>
                      <th>Price</th>
                      <th>Date</th>
                      <th colspan="3">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                      <?php
					$ctr = 1;
          
					$sql_query="SELECT * FROM invoice WHERE comp_name='$comp_name'";
					$result_set=mysqli_query($conn,$sql_query);
					while($row=mysqli_fetch_row($result_set))
					{
						?>
							<tr>
								<td><?php echo $ctr; ?></td>
								<td><?php echo $row[2]; ?></td>
								<td><?php echo $row[3]; ?></td>
								<td><?php echo $row[4]; ?></td>
								<td><?php echo $row[5]; ?></td>
                <td><?php echo $row[6]; ?></td>
								<td align="center"><button class="btn btn-info" data-toggle="modal" data-target="#edit-<?php echo $row[0]; ?>">Edit</button></td>
								
   <div id="edit-<?php echo $row[0]; ?>" tabindex="-1" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Edit Invoice</h4>
      </div>
	  <form action="" name="myForm" method="post">
      <div class="modal-body">
					<input type="hidden" name="update_id" value="<?php echo $row[0]; ?>" >
					<label>Customer Name</label>
					<input type="text" name="update_name" id="update_name" class="form-control" value="<?php echo $row[2]; ?>" required>
					<label>Product</label>
					<input type="text" name="update_pro" id="update_pro" class="form-control" value="<?php echo $row[3]; ?>" required>
					<label>Quantity</label>
					<input type="number" min="1" name="update_quant" id="update_quant" class="form-control" value="<?php echo $row[4]; ?>" required>
          <label>Price</label>
					<input type="number" min="1" name="update_price" id="update_price" class="form-control" value="<?php echo $row[5]; ?>" required>
					<label>Date</label>
					<input type="date" name="update_date" id="update_date" class="form-control" value="<?php echo $row[6]; ?>" required>
      </div>
      <div class="modal-footer">
		<button type="submit" name="add" class="btn btn-success">Update</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
	  </form>
    </div>
  </div>
</div>
			  <td align="center"><a href="javascript:delete_id('<?php echo $row[0]; ?>')" class="btn btn-warning">DELETE</a></td>
        <td align="center"><a href="javascript:view_id('<?php echo $row[0]; ?>')" class="btn btn-primary">VIEW</a></td>
							</tr>
					<?php
						$ctr++;
						}
					?>
                    </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>  
      </div>
    </div>
    <!-- Javascripts-->
    <script src="../js/jquery-2.1.4.min.js"></script>
    <script src="../js/essential-plugins.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/plugins/pace.min.js"></script>
    <script src="../js/main.js"></script>
    <script type="text/javascript" src="../js/plugins/chart.js"></script>
    <script>
      function validateForm()
      {
        if (document.getElementById("name").value === "" )
		{
            alert("Please insert the customer name");
			window.setTimeout(function ()
			{
				document.getElementById('name').focus();
			}, 0);
		return false;
        }
		else if (!/^[a-zA-Z ]*$/g.test(document.getElementById("name").value))
		{
			alert("Customer name must be in alphabet only");
			window.setTimeout(function ()
			{
				document.getElementById('name').focus();
			}, 0);
		return false;
		}
    else if (document.getElementById("pro").value === "" )
		{
            alert("Please insert the product");
			window.setTimeout(function ()
			{
				document.getElementById('pro').focus();
			}, 0);
		return false;
        }
		else if (!/^[a-zA-Z ]*$/g.test(document.getElementById("pro").value))
		{
			alert("Product must be in alphabet only");
			window.setTimeout(function ()
			{
				document.getElementById('pro').focus();
			}, 0);
		return false;
		}
		else if (document.getElementById("quant").value === "" || isNaN(document.getElementById("quant").value))
		{
            alert("Please insert the quantity number all in numeric");
			window.setTimeout(function ()
			{
				document.getElementById('quant').focus();
			}, 0);
		return false;
        }
        else if (document.getElementById("price").value === "" || isNaN(document.getElementById("price").value))
		{
            alert("Please insert the priceall in numeric");
			window.setTimeout(function ()
			{
				document.getElementById('price').focus();
			}, 0);
		return false;
        }
        else if (document.getElementById("date").value === "" )
		{
            alert("Please insert the date");
			window.setTimeout(function ()
			{
				document.getElementById('date').focus();
			}, 0);
		return false;
        }
		else
        {
          document.getElementsByName("insert")[0].type = "submit";
        }
    }      
    </script>

    <script type="text/javascript">
	function delete_id(id)
	{
		if(confirm('Are you sure want to delete the invoice?'))
		{
			window.location.href='invoice.php?delete_id='+id;
		}
	}
  
  function view_id(id)
	{
			window.location.href='printinvo.php?view_id='+id;
	}
	</script>
  </body>
</html>